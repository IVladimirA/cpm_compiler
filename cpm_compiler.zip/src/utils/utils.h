#ifndef IO_UTILS_H
#define IO_UTILS_H

#include "../mixed/mixed.h"

void print(std::string string);
Mixed input(std::string string);

#endif